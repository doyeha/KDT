
인스타 아이디 비밀번호 입력 필요

셀레니움으로 진입 시 로그인 기록 저장 / 나중에 하기 선택 탭 뜸 (랜덤이므로 이 경우에는 뜰 경우에 나중에 하기로 넘어가도록 설정 필요)
DB 연결해서 저장

1. DB 저장 쓰레드
2. 크롤링 하는 쓰레드

크롤링 시 어떤 정보를 수집할 것 인가 선택
1. 태그
2. 아이디

크롤링 가능한 목록
1. 계정주 아이디
2. 본문 글
3. 해시태그

# LoginView -> MainView 조건 충족 시 전환
방법 1. 컨트롤 클래스를 만들어 LoginView에서 조건을 충족하면 닫히고, 이후에 MainView가 뜨도록 컨트롤함.
방법 2. 부모-자식 관계 활용 // Main에서 Login을 직접 제어 - 큰 프로젝트에는 비효율적이라고 함.
방법 3. QStackedWidget 활용
방법 4. 시그널 - 슬롯 방식.

DB 저장은 일단 sqlite3 쓰고, 
https://devyurim.github.io/python/crawler/2018/08/11/crawler-2.html


CONDA 3.8.19
가상환경 slpj
[package] selenium, sqlite3, pyQT5

처음에 로그인 View에서 로그인


로그인 진입 시 
https://www.instagram.com/sem/campaign/emailsignup/?campaign_id=13530338586&extra_1=s%7Cc%7C547419126422%7Ce%7Cinsta%20gram%7C&placement=&creative=547419126422&keyword=insta%20gram&partner_id=googlesem&extra_2=campaignid%3D13530338586%26adgroupid%3D126262418054%26matchtype%3De%26network%3Dg%26source%3Dnotmobile%26search_or_content%3Ds%26device%3Dc%26devicemodel%3D%26adposition%3D%26target%3D%26targetid%3Dkwd-1321618850291%26loc_physical_ms%3D9217072%26loc_interest_ms%3D%26feeditemid%3D%26param1%3D%26param2%3D&gad_source=1&gclid=CjwKCAiA9bq6BhAKEiwAH6bqoAMjrL5H_47xcosqTNLO_5ApyVfLHltyOLmka64hKvikaE8B1jUhhhoCudsQAvD_BwE
가입 권유 화면이 먼저 뜸.
이 화면일 시, 로그인 화면인 여기로 이동.
https://www.instagram.com/accounts/login/?source=auth_switcher
그 담에 로그인 하더라도 로그인 정보 저장 물음.
https://www.instagram.com/accounts/onetap/?next=%2F


로그인 정보 저장하겠냐고 묻는 창.
https://www.instagram.com/accounts/onetap/?next=%2F
selector = #mount_0_0_K8 > div > div > div.x9f619.x1n2onr6.x1ja2u2z > div > div > div.x78zum5.xdt5ytf.x1t2pt76.x1n2onr6.x1ja2u2z.x10cihs4 > div.x9f619.xvbhtw8.x78zum5.x168nmei.x13lgxp2.x5pf9jr.xo71vjh.x1uhb9sk.x1plvlek.xryxfnj.x1c4vz4f.x2lah0s.x1q0g3np.xqjyukv.x1qjc9v5.x1oa3qoh.x1qughib > div.x1gryazu.xh8yej3.x10o80wk.x14k21rp.x17snn68.x6osk4m.x1porb0y.x8vgawa > section > main > div > div > div > div > div
XPATH = //*[@id="mount_0_0_K8"]/div/div/div[2]/div/div/div[1]/div[1]/div[1]/section/main/div/div/div/div/div
fullXPATH = /html/body/div[2]/div/div/div[2]/div/div/div[1]/div[1]/div[1]/section/main/div/div/div/div/div


좋아요
element = <span class="html-span xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x1hl2dhg x16tdsg8 x1vvkbs">8만</span>

selector = body > div.x1n2onr6.xzkaem6 > div.x9f619.x1n2onr6.x1ja2u2z > div > div.x1uvtmcs.x4k7w5x.x1h91t0o.x1beo9mf.xaigb6o.x12ejxvf.x3igimt.xarpa2k.xedcshv.x1lytzrv.x1t2pt76.x7ja8zs.x1n2onr6.x1qrby5j.x1jfb8zj > div > div > div > div > div.xb88tzc.xw2csxc.x1odjw0f.x5fp0pe.x1qjc9v5.xjbqb8w.x1lcm9me.x1yr5g0i.xrt01vj.x10y3i5r.xr1yuqi.xkrivgy.x4ii5y1.x1gryazu.x15h9jz8.x47corl.xh8yej3.xir0mxb.x1juhsu6 > div > article > div > div.x1qjc9v5.x972fbf.xcfux6l.x1qhh985.xm0m39n.x9f619.x78zum5.xdt5ytf.x1iyjqo2.x5wqa0o.xln7xf2.xk390pu.xdj266r.x11i5rnm.xat24cr.x1mh8g0r.x65f84u.x1vq45kp.xexx8yu.x4uap5.x18d9i69.xkhd6sd.x1n2onr6.x11njtxf > div > div > div.x78zum5.xdt5ytf.x1q2y9iw.x1n2onr6.xh8yej3.x9f619.x1iyjqo2.x18l3tf1.x26u7qi.xy80clv.xexx8yu.x4uap5.x18d9i69.xkhd6sd > section.x12nagc.x182iqb8.x1pi30zi.x1swvt13 > div > div > span > a > span > span

XPATH = /html/body/div[6]/div[1]/div/div[3]/div/div/div/div/div[2]/div/article/div/div[2]/div/div/div[2]/section[2]/div/div/span/a/span/span

fullXPATH = /html/body/div[6]/div[1]/div/div[3]/div/div/div/div/div[2]/div/article/div/div[2]/div/div/div[2]/section[2]/div/div/span/a/span/span




수정 필요 사항
1205. 0919 = 아이디 비밀번호 에러 메세지가 너무 늦게 나온다 . 


크롤링 시 조건들.
    # 검색어 (태그 or 게시자 아이디)
    # 게시글 내용
    # 좋아요 수
    # 게시자 이름
    # 해시태그
    # 크롤링 게시글 횟수

현재는 링크를 받아서 이후에 그 링크에 쫘라락인데.
접근 방식을 바꾸어야할까?
오히려 시간면에서는 애매할 수 도 있음. 일단은 그렇게 진행하자.
