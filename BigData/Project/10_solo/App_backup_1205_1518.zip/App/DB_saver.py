import sqlite3

from PyQt5 import uic
from PyQt5.QtCore import (QThread, pyqtSignal)
from collections import deque

class DB_Saver(QThread):
    def __init__(self, signal):
        super().__init__()
        self.signal = signal
        self.link_deque = deque()
        self.con = sqlite3.connect("insta.db")
        self.Cur = self.con.cursor()
        self.create_table()
         # 링크 받아옴.


    # [LINK, ONER_ID, MAINTEXT, LOVER, HASHTAG]
    def run(self):
        self.signal.link_saver_signal.connect(self.data_receiver)
        while True:
            if self.link_deque:
                save_link = self.link_deque.popleft()
                self.insert_linkdata(save_link)
            else:
                self.sleep(1)


    def insert_linkdata(self, link):
        try:
            sql = "INSERT OR IGNORE INTO insta (LINK) VALUES (?)"
            data = (link)
            self.Cur.execute(sql, data)
        except Exception as e:
            print("에러 발생", e)
        finally:
            self.con.commit()
            # "INSERT INTO example_table (column1, column2) VALUES (?, ?)", ('value1', 'value2')
            # "INSERT OR REPLACE INTO example_table (id, name) VALUES (?, ?)", (1, 'John')
            # cursor.execute("INSERT OR IGNORE INTO example_table (id, name) VALUES (?, ?)", (1, 'John'))



    def data_receiver(self, link):
        self.link_deque.append(link)

    # 테이블 생성 
    def create_table(self):
        sql = """CREATE TABLE IF NOT EXISTS insta(
            LINK TEXT,
            Oner_ID TEXT,
            MAINTEXT TEXT,
            LOVER TEXT
            HASHTAG TEXT
            );"""
        self.Cur.execute(sql)



    # def run(self):
    #     SQL = DB_Saver()
    #     SQL.create_table
    #     SQL.insert_data("계정주인", "본문내용", "해시태그")

