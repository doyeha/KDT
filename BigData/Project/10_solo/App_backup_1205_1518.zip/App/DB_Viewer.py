import sqlite3

from PyQt5 import uic
from PyQt5 import QtWidgets, QtGui
from PyQt5.QtWidgets import *

from PyQt5.QtCore import (QThread, pyqtSignal)

from collections import deque


class DB_Viewer(QThread):
    def __init__(self, signal, showtable):
        super().__init__()
        self.signal = signal
        self.showtable = showtable
        # self.con = sqlite3.connect("insta.db")
        self.con = sqlite3.connect("insta.db")
        self.Cur = self.con.cursor()
        self.showtable =  self.findChild(QtWidgets.QTableWidget, "insta_table")

    def run(self):
        if self.showtable is not None:
            self.load_data()


    def load_data(self):
        self.showtable.clearContents()
        self.showtable.setRowCount(0)
        # self.Cur.execute("SELECT * FROM insta")
        self.Cur.execute("SELECT * FROM insta")
        data = self.Cur.fetchall()
        
        for row_index, row_data in enumerate(data):
            self.showtable.insertRow(row_index)
            for col_index, per_data in enumerate(row_data):
                item = QTableWidgetItem(str(per_data))
                self.showtable.setItem(row_index,col_index, item)



