
from PyQt5.QtCore import pyqtSignal,QThread
import threading
from PyQt5.QtWidgets import *

# 본인 모듈 import 
from signal_col import signal_collection

# 셀레니움 크롤링 모듈
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys

import time
import random as rd
import pandas as pd

class crawling_sele(QThread):
    def __init__(self, signal):
        super().__init__()
        self.ID = None
        self.PW = None
        self.signal = signal
        # self.signal.idpw_signal.connect(self.login_info_receiver)   # idpw 받아옴.
        self.open_check = True
        self.signal.open_driver_Mainview_signal.connect(self.open_driver)
        self.login_try = False
        self.link_point = False

        # 검색 조건
        self.search_type_condition, self.searh_word_condition, self.MainText_condition, self.Oner_ID_condition, self.lover_condition, self.Hash_condition, self.want_amount_condition = None,None, None, None, None, None, None

        print("쓰레드 시작")
        

    def open_driver(self, ch):
        if ch:
            print("셀레니움 실행")
            options = Options()
            user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
            options.add_argument(f"user-agent={user_agent}")
            chrome_driver_path = "chromedriver.exe"  # 크롬 드라이버 설치 경로 입력
            service = Service(chrome_driver_path)
            # 웹 드라이버 실행
            self.driver = webdriver.Chrome(options=options)
            self.url ="https://www.instagram.com"
            self.driver.get(self.url)
            # self.driver.set_window_position(100, 100)
            # self.driver.set_window_size(1024, 768)
            # self.open_check = False
            ch = False
            

    
    idinput_path = [ # 로그인 ID 입력 창 
        # (By.CLASS_NAME, '_aa4b _add6 _ac4d _ap35'),
        # (By.CLASS_NAME, '_aa4b._add6._ac4d._ap35'),
        (By.CSS_SELECTOR,'#loginForm > div > div:nth-child(1) > div > label > input'),
        (By.XPATH, '//*[@id="loginForm"]/div/div[1]/div/label/input'),
        (By.XPATH, "/html/body/div[2]/div/div/div[2]/div/div/div[1]/div[1]/div/section/main/div/div/div[1]/div[2]/div/form/div/div[1]/div/label/input")
        ]
    pwinput_path = [ # 로그인 PW 입력 창 
        # (By.CLASS_NAME, '_aa4b _add6 _ac4d _ap35'),
        # (By.CLASS_NAME, '_aa4b._add6._ac4d._ap35'),
        (By.CSS_SELECTOR, '#loginForm > div > div:nth-child(2) > div > label > input'),
        (By.XPATH, '//*[@id="loginForm"]/div/div[2]/div/label/input'),
        (By.XPATH, '/html/body/div[2]/div/div/div[2]/div/div/div[1]/div[1]/div/section/main/div/div/div[1]/div[2]/div/form/div/div[2]/div/label/input')
        ]
    log_submit_path = [ # 로그인 입력 버튼 클릭.
        # (By.CLASS_NAME, 'x9f619.xjbqb8w.x78zum5.x168nmei.x13lgxp2.x5pf9jr.xo71vjh.x1n2onr6.x1plvlek.xryxfnj.x1c4vz4f.x2lah0s.xdt5ytf.xqjyukv.x1qjc9v5.x1oa3qoh.x1nhvcw1'),
        # (By.CLASS_NAME, 'x9f619 xjbqb8w x78zum5 x168nmei x13lgxp2 x5pf9jr xo71vjh x1n2onr6 x1plvlek xryxfnj x1c4vz4f x2lah0s xdt5ytf xqjyukv x1qjc9v5 x1oa3qoh x1nhvcw1'),
        (By.CSS_SELECTOR, '#loginForm > div > div:nth-child(3) > button > div'),
        (By.XPATH, '//*[@id="loginForm"]/div/div[3]/button/div'),
        (By.XPATH, '/html/body/div[2]/div/div/div[2]/div/div/div[1]/div[1]/div/section/main/article/div[2]/div[1]/div[2]/div/form/div/div[3]/button/div')
        ]
    fail_login_path = [ # 로그인 실패 문구 찾는 path
        (By.CLASS_NAME, 'x1lliihq x1plvlek xryxfnj x1n2onr6 x1ji0vk5 x18bv5gf x193iq5w xeuugli x1fj9vlw x13faqbe x1vvkbs x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x x1i0vuye xvs91rp xo1l8bm x5n08af x1tu3fi x3x7a5m x10wh9bi x1wdrske x8viiok x18hxmgj'),
        (By.CLASS_NAME, 'x1lliihq x1plvlek xryxfnj x1n2onr6 x1ji0vk5 x18bv5gf x193iq5w xeuugli x1fj9vlw x13faqbe x1vvkbs x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x x1i0vuye xvs91rp xo1l8bm x5n08af x1tu3fi x3x7a5m x10wh9bi x1wdrske x8viiok x18hxmgj'.replace(" ",".")),
        (By.CSS_SELECTOR, '#loginForm > span'),
        (By.XPATH, '//*[@id="loginForm"]/span'),
        (By.XPATH, '/html/body/div[2]/div/div/div[2]/div/div/div[1]/div[1]/div/section/main/div/div/div[1]/div[2]/div/form/span')
        ]
    login_info_question_path = [    # 로그인 성공 후 나중에 하기 path
        (By.CLASS_NAME, 'x1i10hfl xjqpnuy xa49m3k xqeqjp1 x2hbi6w xdl72j9 x2lah0s xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r x2lwn1j xeuugli x1hl2dhg xggy1nq x1ja2u2z x1t137rt x1q0g3np x1lku1pv x1a2a7pz x6s0dn4 xjyslct x1ejq31n xd10rxx x1sy0etr x17r0tee x9f619 x1ypdohk x1f6kntn xwhw2v2 xl56j7k x17ydfre x2b8uid xlyipyv x87ps6o x14atkfc xcdnw81 x1i0vuye xjbqb8w xm3z3ea x1x8b98j x131883w x16mih1h x972fbf xcfux6l x1qhh985 xm0m39n xt0psk2 xt7dq6l xexx8yu x4uap5 x18d9i69 xkhd6sd x1n2onr6 x1n5bzlp x173jzuc x1yc6y37'.replace(" ",".")),
        (By.CSS_SELECTOR, '#mount_0_0_js > div > div > div > div.x9f619.x1n2onr6.x1ja2u2z > div > div > div.x78zum5.xdt5ytf.x1t2pt76.x1n2onr6.x1ja2u2z.x10cihs4 > div.x9f619.xvbhtw8.x78zum5.x168nmei.x13lgxp2.x5pf9jr.xo71vjh.x1uhb9sk.x1plvlek.xryxfnj.x1c4vz4f.x2lah0s.x1q0g3np.xqjyukv.x1qjc9v5.x1oa3qoh.x1qughib > div.x1gryazu.xh8yej3.x10o80wk.x14k21rp.x17snn68.x6osk4m.x1porb0y.x8vgawa > section > main > div > div > div > div > div'),
        (By.XPATH, '//*[@id="mount_0_0_js"]/div/div/div/div[2]/div/div/div[1]/div[1]/div[1]/section/main/div/div/div/div/div'),
        (By.XPATH, '/html/body/div[2]/div/div/div/div[2]/div/div/div[1]/div[1]/div[1]/section/main/div/div/div/div/div')
        ]
    MainText_path = [   # 본문 찾기
        (By.CLASS_NAME, "_ap3a._aaco._aacu._aacx._aad7._aade"),
        (By.CLASS_NAME, "x193iq5w.xeuugli.x1fj9vlw.x13faqbe.x1vvkbs.xt0psk2.x1i0vuye.xvs91rp.xo1l8bm.x5n08af.x10wh9bi.x1wdrske.x8viiok.x18hxmgj"),
        (By.CSS_SELECTOR, "#mount_0_0_Nn > div > div > div.x9f619.x1n2onr6.x1ja2u2z > div > div > div.x78zum5.xdt5ytf.x1t2pt76.x1n2onr6.x1ja2u2z.x10cihs4 > div.x9f619.xvbhtw8.x78zum5.x168nmei.x13lgxp2.x5pf9jr.xo71vjh.x1uhb9sk.x1plvlek.xryxfnj.x1c4vz4f.x2lah0s.x1q0g3np.xqjyukv.x1qjc9v5.x1oa3qoh.x1qughib > div.x1gryazu.xh8yej3.x10o80wk.x14k21rp.x17snn68.x6osk4m.x1porb0y.x8vgawa > section > main > div > div.x6s0dn4.x78zum5.xdt5ytf.xdj266r.xkrivgy.xat24cr.x1gryazu.x1n2onr6.xh8yej3 > div > div.x4h1yfo > div > div.x5yr21d.xw2csxc.x1odjw0f.x1n2onr6 > div > div:nth-child(1) > div > div.x9f619.xjbqb8w.x78zum5.x168nmei.x13lgxp2.x5pf9jr.xo71vjh.x1uhb9sk.x1plvlek.xryxfnj.x1iyjqo2.x2lwn1j.xeuugli.x1q0g3np.xqjyukv.x1qjc9v5.x1oa3qoh.x1nhvcw1 > div > span > div > span"),
        (By.XPATH, "//*[@id='mount_0_0_Nn']/div/div/div[2]/div/div/div[1]/div[1]/div[1]/section/main/div/div[1]/div/div[2]/div/div[2]/div/div[1]/div/div[2]/div/span/div/span"),
        (By.XPATH, '/html/body/div[2]/div/div/div[2]/div/div/div[1]/div[1]/div[1]/section/main/div/div[1]/div/div[2]/div/div[2]/div/div[1]/div/div[2]/div/span/div/span')
        ]
    scroll_selectors = [# 스크롤 가능한 요소 찾기
        (By.CLASS_NAME, "_a9z6._a9za"),
        (By.CLASS_NAME, "x5yr21d.xw2csxc.x1odjw0f.x1n2onr6"),
        (By.XPATH, '//*[@id="mount_0_0_IQ"]/div/div/div[2]/div/div/div[1]/div[1]/div[1]/section/main/div[2]/div[1]/article/div/div[2]/div/div[2]/div[1]/ul'),
        (By.XPATH, '/html/body/div[2]/div/div/div[2]/div/div/div[1]/div[1]/div[1]/section/main/div/div[1]/div/div[2]/div/div[2]'),
        (By.CSS_SELECTOR, '#mount_0_0_Nn > div > div > div.x9f619.x1n2onr6.x1ja2u2z > div > div > div.x78zum5.xdt5ytf.x1t2pt76.x1n2onr6.x1ja2u2z.x10cihs4 > div.x9f619.xvbhtw8.x78zum5.x168nmei.x13lgxp2.x5pf9jr.xo71vjh.x1uhb9sk.x1plvlek.xryxfnj.x1c4vz4f.x2lah0s.x1q0g3np.xqjyukv.x1qjc9v5.x1oa3qoh.x1qughib > div.x1gryazu.xh8yej3.x10o80wk.x14k21rp.x17snn68.x6osk4m.x1porb0y.x8vgawa > section > main > div > div.x6s0dn4.x78zum5.xdt5ytf.xdj266r.xkrivgy.xat24cr.x1gryazu.x1n2onr6.xh8yej3 > div > div.x4h1yfo > div > div.x5yr21d.xw2csxc.x1odjw0f.x1n2onr6')
        ]
    comments_path = [# 댓글창 전체를 리스트로 뽑아내는 경로
        (By.CLASS_NAME, 'x9f619.xjbqb8w.x78zum5.x168nmei.x13lgxp2.x5pf9jr.xo71vjh.x1uhb9sk.x1plvlek.xryxfnj.x1c4vz4f.x2lah0s.xdt5ytf.xqjyukv.x1qjc9v5.x1oa3qoh.x1nhvcw1'),
        (By.XPATH, "/html/body/div[2]/div/div/div[2]/div/div/div[1]/div[1]/div[1]/section/main/div/div[1]/div/div[2]/div/div[2]/div/div[2]/div[1]/div[1]/div/div[2]/div[1]/div[1]/div"),
        (By.CSS_SELECTOR, '#mount_0_0_Nn > div > div > div.x9f619.x1n2onr6.x1ja2u2z > div > div > div.x78zum5.xdt5ytf.x1t2pt76.x1n2onr6.x1ja2u2z.x10cihs4 > div.x9f619.xvbhtw8.x78zum5.x168nmei.x13lgxp2.x5pf9jr.xo71vjh.x1uhb9sk.x1plvlek.xryxfnj.x1c4vz4f.x2lah0s.x1q0g3np.xqjyukv.x1qjc9v5.x1oa3qoh.x1qughib > div.x1gryazu.xh8yej3.x10o80wk.x14k21rp.x17snn68.x6osk4m.x1porb0y.x8vgawa > section > main > div > div.x6s0dn4.x78zum5.xdt5ytf.xdj266r.xkrivgy.xat24cr.x1gryazu.x1n2onr6.xh8yej3 > div > div.x4h1yfo > div > div.x5yr21d.xw2csxc.x1odjw0f.x1n2onr6 > div > div.x78zum5.xdt5ytf.x1iyjqo2 > div:nth-child(1) > div:nth-child(1) > div > div.x9f619.xjbqb8w.x78zum5.x168nmei.x13lgxp2.x5pf9jr.xo71vjh.x1uhb9sk.x1plvlek.xryxfnj.x1iyjqo2.x2lwn1j.xeuugli.x1q0g3np.xqjyukv.x1qjc9v5.x1oa3qoh.x1nhvcw1 > div.x9f619.xjbqb8w.x78zum5.x168nmei.x13lgxp2.x5pf9jr.xo71vjh.x1uhb9sk.x1plvlek.xryxfnj.x1iyjqo2.x2lwn1j.xeuugli.xdt5ytf.xqjyukv.x1qjc9v5.x1oa3qoh.x1nhvcw1 > div:nth-child(1) > div'),
        (By.CSS_SELECTOR, '#mount_0_0_mD > div > div > div.x9f619.x1n2onr6.x1ja2u2z > div > div > div.x78zum5.xdt5ytf.x1t2pt76.x1n2onr6.x1ja2u2z.x10cihs4 > div.x9f619.xvbhtw8.x78zum5.x168nmei.x13lgxp2.x5pf9jr.xo71vjh.xvkph5b.x1uhb9sk.x1plvlek.xryxfnj.x1c4vz4f.x2lah0s.x1q0g3np.xqjyukv.x1qjc9v5.x1oa3qoh.x1qughib > div.x10o80wk.x14k21rp.xh8yej3.x8vgawa > section > main > div > div.x6s0dn4.x78zum5.xdt5ytf.xdj266r.xkrivgy.xat24cr.x1gryazu.x1n2onr6.xh8yej3 > div > div.x4h1yfo > div > div.x5yr21d.xw2csxc.x1odjw0f.x1n2onr6 > div > div:nth-child(3) > div > div > div.x9f619.xjbqb8w.x78zum5.x168nmei.x13lgxp2.x5pf9jr.xo71vjh.x1uhb9sk.x1plvlek.xryxfnj.x1iyjqo2.x2lwn1j.xeuugli.x1q0g3np.xqjyukv.x1qjc9v5.x1oa3qoh.x1nhvcw1 > div > div:nth-child(1) > div'),
        (By.XPATH, '//*[@id="mount_0_0_mD"]/div/div/div[2]/div/div/div[1]/div[1]/div[1]/section/main/div/div[1]/div/div[2]/div/div[2]/div/div[3]/div/div/div[2]/div/div[1]/div')
        ]
    comment_box_PATH = [    # 본문 + 일반 댓글의 전체 댓글 박스
    (By.CLASS_NAME, 'x9f619 xjbqb8w x78zum5 x168nmei x13lgxp2 x5pf9jr xo71vjh x1uhb9sk x1plvlek xryxfnj x1c4vz4f x2lah0s xdt5ytf xqjyukv x1qjc9v5 x1oa3qoh x1nhvcw1'.replace(" ",".")),
    (By.XPATH, '/html/body/div[2]/div/div/div/div[2]/div/div/div[1]/div[1]/div[1]/section/main/div/div[1]/div/div[2]/div/div[2]/div/div[2]/div[1]'),
    (By.XPATH,'//*[@id="mount_0_0_D7"]/div/div/div/div[2]/div/div/div[1]/div[1]/div[1]/section/main/div/div[1]/div/div[2]/div/div[2]/div/div[2]/div[1]'),
    (By.CSS_SELECTOR,'#mount_0_0_D7 > div > div > div > div.x9f619.x1n2onr6.x1ja2u2z > div > div > div.x78zum5.xdt5ytf.x1t2pt76.x1n2onr6.x1ja2u2z.x10cihs4 > div.x9f619.xvbhtw8.x78zum5.x168nmei.x13lgxp2.x5pf9jr.xo71vjh.x1uhb9sk.x1plvlek.xryxfnj.x1c4vz4f.x2lah0s.x1q0g3np.xqjyukv.x1qjc9v5.x1oa3qoh.x1qughib > div.x1gryazu.xh8yej3.x10o80wk.x14k21rp.x17snn68.x6osk4m.x1porb0y.x8vgawa > section > main > div > div.x6s0dn4.x78zum5.xdt5ytf.xdj266r.xkrivgy.xat24cr.x1gryazu.x1n2onr6.xh8yej3 > div > div.x4h1yfo > div > div.x5yr21d.xw2csxc.x1odjw0f.x1n2onr6 > div > div.x78zum5.xdt5ytf.x1iyjqo2 > div:nth-child(1)')
    ]
    button_path = [ # 대댓글 열기 버튼 path
        (By.CLASS_NAME, 'x1i10hfl.xjbqb8w.x1ejq31n.xd10rxx.x1sy0etr.x17r0tee.x972fbf.xcfux6l.x1qhh985.xm0m39n.x9f619.x1ypdohk.xt0psk2.xe8uvvx.xdj266r.x11i5rnm.xat24cr.x1mh8g0r.xexx8yu.x4uap5.x18d9i69.xkhd6sd.x16tdsg8.x1hl2dhg.xggy1nq.x1a2a7pz.x87ps6o.x1d5wrs8'),
        (By.CSS_SELECTOR, '#mount_0_0_AB > div > div > div > div.x9f619.x1n2onr6.x1ja2u2z > div > div > div.x78zum5.xdt5ytf.x1t2pt76.x1n2onr6.x1ja2u2z.x10cihs4 > div.x9f619.xvbhtw8.x78zum5.x168nmei.x13lgxp2.x5pf9jr.xo71vjh.x1uhb9sk.x1plvlek.xryxfnj.x1c4vz4f.x2lah0s.x1q0g3np.xqjyukv.x1qjc9v5.x1oa3qoh.x1qughib > div.x1gryazu.xh8yej3.x10o80wk.x14k21rp.x17snn68.x6osk4m.x1porb0y.x8vgawa > section > main > div > div.x6s0dn4.x78zum5.xdt5ytf.xdj266r.xkrivgy.xat24cr.x1gryazu.x1n2onr6.xh8yej3 > div > div.x4h1yfo > div > div.x5yr21d.xw2csxc.x1odjw0f.x1n2onr6 > div > div.x78zum5.xdt5ytf.x1iyjqo2 > div:nth-child(6) > div.x9f619.xjbqb8w.x78zum5.x168nmei.x13lgxp2.x5pf9jr.xo71vjh.x1uhb9sk.x1plvlek.xryxfnj.x1c4vz4f.x2lah0s.xdt5ytf.xqjyukv.x1qjc9v5.x1oa3qoh.x1nhvcw1.x540dpk > div'),
        (By.XPATH, '//*[@id="mount_0_0_AB"]/div/div/div/div[2]/div/div/div[1]/div[1]/div[1]/section/main/div/div[1]/div/div[2]/div/div[2]/div/div[2]/div[6]/div[2]/div'),
        (By.XPATH, '/html/body/div[2]/div/div/div/div[2]/div/div/div[1]/div[1]/div[1]/section/main/div/div[1]/div/div[2]/div/div[2]/div/div[2]/div[6]/div[2]/div')
    ]


    # path 리스트 입력 시 크롤링 되는 text 리턴
    def text_finder(self, path_list):
        # 조건 충족하는 버튼 클릭시키는 함수.
        for by, path in path_list:
            try:
                target_text = self.driver.find_element(by, path).text
                break # 되면 더 찾지마
            except:           
                continue
        self.timesleep_under_1s()
        return target_text
        # 이걸 해서 찾는 결과물.
        # 1. 조건에 맞는 버튼 클릭
        # 2. 조건 충족 시 text 출력
        # 3. 조건 미충족 시 다음 이벤트로 안넘어가게 하기.

    # 찾는 리스트로 해서 텍스트 입력하는 함수
    # 아이디, 비밀번호 
    def text_sendkey(self, path_list, input_text):
        for by, path in path_list:  # 아이디 입력
            try:
                # self.driver.find_element(by, path).clear()
                self.driver.find_element(by, path).send_keys(Keys.LEFT_SHIFT, Keys.HOME, Keys.BACKSPACE)
                self.driver.find_element(by, path).send_keys(input_text)
                break # 되면 더 찾지마
            except:           
                continue
        self.timesleep_under_1s()


    def click_target(self, path_list, button_text):
        # 조건을 추가해야하나?
        for by, path in path_list:
            try:
                self.login_btn = self.driver.find_element(by, path)
                if self.login_btn.text == button_text:
                    self.driver.find_element(by, path).click()
                break # 되면 더 찾지마
            except:           
                continue
        self.timesleep_under_1s()


    def run(self):
        # 만약 로그인창이라면?
        self.signal.idpw_signal.connect(self.login_info_receiver)     # ID/PW 비밀번호 받아오면 작동되도록 시그널화
        # 조건 여기서 추가해서 조건을 받아서 그에 따라 실행되도록 해야한다.
        self.signal.start_crawling_signal.connect(self.search_condition_receiver)    # 이때 받아야만 본격적인 크롤링 시작되도록 함.
        # if self.link_point:
        #     self.tag_link_crawler(self.search_type_condition, self.searh_word_condition,self.want_amount_condition)
    
    def search_condition_receiver(self, type, searh_word, text, id, love, hash, amount):
        self.search_type_condition = type   # str
        self.searh_word_condition = searh_word
        # 긁어올 내용   checkBox
        self.MainText_condition = text   # bool
        self.Oner_ID_condition = id
        self.lover_condition =  love
        self.Hash_condition = hash
        # 수집할 양 - EditLabel
        self.want_amount_condition = amount # int
        print("조건 : ", type, searh_word,  id, text, love, hash, amount)
        # self.link_point = True
        self.tag_link_crawler(self.search_type_condition, self.searh_word_condition,self.want_amount_condition)

    
    # 일단 링크 긁어서 DB에 넣기.
    def tag_link_crawler(self, type, searh_word, amount):
        # for tag in ['먹스타그램']:    # 검색할 태그 입력
        links = 0
        if type =="태그":
            base_url = "https://www.instagram.com/explore/search/keyword/?q=%23"
        elif type =="사용자 ID":
            base_url = "https://www.instagram.com/"
        else:
            print("오류 발생!")
        
        # 일단 태그 하나만 검색할 수 있도록 함.
        url = base_url+searh_word
        self.driver.get(url) 
        time.sleep(rd.choice([4.7,5,5.3]))
            # 태그서치 url
        while links <= amount:
            
            print(f"--- 진행중 {links}/{amount}----")
            # 링크가 원하는 양만큼 차면 멈출건데. 그걸 DB에서 확인을 해야함. 
            # 링크가 나오면 바로 DB 저장 쓰레드에 넣자.
            # 스크롤은 계속 내려야하니까. 이후에 저 조건이 충족이 안되면 내려가는 걸로.
            first_result = self.driver.find_elements(By.CSS_SELECTOR, "a.x1i10hfl.xjbqb8w.x1ejq31n")
            # 처음에 온갖게 리스트 뭉탱이로 나오고
            for f in first_result:  # 여기서 하나씩 뽑아서? href가 포함되어있는 것만 한다.
                link = f.get_attribute("href")
                if "/p/" in link:
                    # 링크는 텍스트야.
                    print("링크된 크롤링 : ",link)
                    links += 1
                    self.signal.link_saver_signal.emit(link)
                    self.timesleep_under_1s()
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            self.timesleep_2s_4s()
            

        self.search_type_condition, self.searh_word_condition,self.want_amount_condition = None, None, None


    """
    def start_crawling(self):
        # 검색어 (태그 or 게시자 아이디)
        # 게시글 내용
        # 좋아요 수
        # 게시자 이름
        # 해시태그
        # 크롤링 게시글 횟수

        # 완성!!!!!!!!!!!!!!!!!!!!!!!!! 
        # 1202. 21:57 기준 일단 오류 발견된거 없음.
        pre_save = 0
        # for link in list(LinkDF['링크'][43637:53124]):  # 노트북 : 음식/요리 43124~66125 | 53124    일단 1만개만
        for link_idx in Link_list:
            hash_list = []
            # link_idx = LinkDF[LinkDF['링크']== link].index.to_list()
            # link_idx = int(link_idx[0])
            link = LinkDF['링크'][link_idx]
            print(f"---------------------{link_idx}/{LinkDF['링크'].shape[0]}---------------------")
            driver.get(link) # 1차 로그인 화면
            time.sleep(rd.choice([3,3.3,3.5,3.7,4.0,4.1,4.3,4.5,4.7,5.0,5.1,5.2,5.3]))   # 계정 정지 방지용
            try: # id 크롤링
                Oner_ID = driver.find_element(By.CLASS_NAME,'x1i10hfl.xjqpnuy.xa49m3k.xqeqjp1.x2hbi6w.xdl72j9.x2lah0s.xe8uvvx.xdj266r.x11i5rnm.xat24cr.x1mh8g0r.x2lwn1j.xeuugli.x1hl2dhg.xggy1nq.x1ja2u2z.x1t137rt.x1q0g3np.x1lku1pv.x1a2a7pz.x6s0dn4.xjyslct.x1ejq31n.xd10rxx.x1sy0etr.x17r0tee.x9f619.x1ypdohk.x1f6kntn.xwhw2v2.xl56j7k.x17ydfre.x2b8uid.xlyipyv.x87ps6o.x14atkfc.xcdnw81.x1i0vuye.xjbqb8w.xm3z3ea.x1x8b98j.x131883w.x16mih1h.x972fbf.xcfux6l.x1qhh985.xm0m39n.xt0psk2.xt7dq6l.xexx8yu.x4uap5.x18d9i69.xkhd6sd.x1n2onr6.x1n5bzlp.xqnirrm.xj34u2y.x568u83')
                Oner_ID = Oner_ID.text
            except:
                Oner_ID = "None"
                LinkDF.at[link_idx, '게시자 아이디'] = "None"
                LinkDF.at[link_idx, '본문 내용'] = "None"
                LinkDF.at[link_idx, '해시태그'] = "None"
                continue    # 아이디도 안 긁혀오는 경우에는 페이지 삭제 확률이 높다.
            print("Oner_ID :", Oner_ID)
            time.sleep(rd.choice([0.3,0.5,0.7,1.0])) 

            # 본문내용
            for by, path in MainText_path:
                try:
                    MainText = driver.find_element(by, path)
                    break # 되면 더 찾지마
                except:               
                    MainText = None
                    continue
            if MainText is not None:
                MainText = MainText.text
            else:   # 본문 글이 없다면 다 None값 처리 
                LinkDF.at[link_idx, '게시자 아이디'] = "None"
                LinkDF.at[link_idx, '본문 내용'] = "None"
                LinkDF.at[link_idx, '해시태그'] = "None"  # 해시태그 중복 제거용
                continue
            # print("Before : MainText :", MainText)
            Maintext_list = MainText.split()
            for t in Maintext_list:
                if "#" in t:                # 본문에 해시태그가 있는 경우, 삭제 및 hash리스트에 빼서 넣어두기.
                    MainText = MainText.replace(t,"")
                    hash_list.append(t)
            time.sleep(rd.choice([0.3,0.5,0.7,1.0])) 
            MainText = re.sub('[^가-힣]+',' ', MainText) # 영어 및 이모티콘 같은 글 삭제
            if len(MainText) < 20:
                MainText = "None" # 전처리, 30자 이하라면 분석이 애매하니 삭제한다.
                insert_tag_row(link_idx, "None", "None", "None")  # 그리고 바로 추가 이후 삭제 처리 필요.
                continue
            else: 
                pass

            # 미리 스크롤 부분 찾아두기
            scrollable_div = None
            for by, selector in scroll_selectors:
                try:
                    scrollable_div = driver.find_element(by, selector)
                    break
                except:
                    pass   

            # 본문에서 없으면 작동.
            # comment_box_PATH는 아래 박스 안에 있는거 찾는건디. 그럼 대댓찾는용이니께? 그냥 댓글이 빠졋네.
            idx = 0
            bad_try = 0
            for by, path in comments_path:
                    try:
                        comment = driver.find_elements(by, path)
                        break
                    except:
                        pass
            Oner_text = ""
            for c in comment:   # 댓글에 있는 태그도 일단 검색해.
                if Oner_ID in c.text:
                    Oner_text += c.text
            for text in Oner_text.split():  # 계정주 글 중에 # 포함되어있는 것들 추가.
                if "#" in text:
                    for t in text.split("#")[1:]:
                        t = "#"+t
                        hash_list.append(t)
            
            time.sleep(rd.choice([0.5,0.7,1.0, 1.1,1.2,1.3]))              
            while (len(hash_list) < 1) and (bad_try<10):
                # 무언가 문제 발생 시 무한 스크롤하고 작동 정지하는 문제 있음.
                # bad_try 로 스크롤 10번만 하는 것으로 제한. 
                for by, path in comment_box_PATH:
                    try:
                        comment_box = driver.find_elements(by, path)
                        break
                    except:
                        pass
                cocom = False
                # 댓글창
                for idx, box in enumerate(comment_box):
                    # print(f"-----------------------------{idx}-----------------------------")
                    if ("모두 보기" in box.text) and (len(box.text)>11) and (box.text.split()[0] == Oner_ID):    # 댓글 전체 + 그냥 답글 1개 모두 보기 이런식으로 또 2개 뜸  # 진짜 왜 .........?
                        for by, path in button_path:
                            try:
                                box.find_element(by, path).click()
                                time.sleep(rd.choice([0.5,0.7,0.9])) 
                                driver.execute_script("arguments[0].scrollTop += arguments[1];", scrollable_div, 100)   # 스크롤 했으니 다시 크롤링 해야지.
                                time.sleep(rd.choice([1.2,1.5,1.7])) 
                                cocom = True
                            except:
                                pass
                # 대댓글 발견 시 작동.
                if cocom:
                    for by, path in comment_box_PATH:
                        try:
                            comment = driver.find_elements(by, path)
                            break
                        except:
                            pass
                    for idx, box in enumerate(comment):
                        if box.text.split() != []:
                            # print(box.text.split())
                            if (box.text.split()[0] == Oner_ID):
                                hash_list = [text for text in box.text.split() if "#" in text]  # 일단 스크롤해서 더 밑에 깊게 묻혀있는게 아니면 갖고옴.
                if len(hash_list) < 1:  # 아니 뭐하느라 남들 댓글달때 지 태그를 안걸어놔 밑으로 계속 가
                    driver.execute_script("arguments[0].scrollTop += arguments[1];", scrollable_div, 300)
                    bad_try += 1
                    time.sleep(rd.choice([1.0, 1.5,1.6,1.9]))
            # def로 했을때는 안되더니 그냥 따로 하니까 LinkDF에 들어가지는 중
            LinkDF.at[link_idx, '게시자 아이디'] = Oner_ID
            LinkDF.at[link_idx, '본문 내용'] = MainText
            LinkDF.at[link_idx, '해시태그'] = list(set(hash_list))  # 해시태그 중복 제거용

            if pre_save % 10 == 0:  # 10번째마다 저장
                LinkDF.to_csv("게시글 크롤링.csv")
            pre_save += 1
            time.sleep(rd.choice([0.5,0.7,1.0,1.2,1.5])) 


                pass
        """
        


    def timesleep_under_1s(self):
        time.sleep(rd.choice([0.1,0.2,0.4,0.5,0.7,0.8,1.0]))

    def timesleep_1s_2s(self):
        time.sleep(rd.choice([1.0,1.2,1.4,1.5,1.7,1.8,2.0]))
    def timesleep_2s_4s(self):
        time.sleep(rd.choice([2.0,2.2,2.4,2.5,2.7,2.8,3.0,3.1,3.2,3.4,3.6,3.8,4.0]))



    def login_info_receiver(self, id, pw, login_try):
        self.ID = id
        self.PW = pw
        self.login_try = login_try
        # print("self.login_try : ", self.login_try)
        self.Try_login()
        
        
    def Try_login(self):
        if self.login_try:
            self.text_sendkey(self.idinput_path, self.ID)
            self.text_sendkey(self.pwinput_path, self.PW)
            self.click_target(self.log_submit_path, "로그인")
            # 일단 여기서 로그인이 되면 문제가 없는데, 만약 문제가 생기면 ?
            self.login_try = False
            time.sleep(4)   # 로그인에 소요되는 시간 
            self.check_login()
      
      # 기능이 많이 느리다. 쓰레드 따로 만드는것이 좋을 듯함.
    def check_login(self):
        # 로그인에 성공했다면? 아래 링크임.
        if self.driver.current_url == 'https://www.instagram.com/accounts/onetap/?next=%2F':
            self.click_target(self.login_info_question_path, "나중에 하기")
            time.sleep(1.5)
            self.signal.login_success_signal.emit(True)
        else:
            print("로그인 실패")
            # 일로 왔으면 로그인 실패 가능성 98%
            # 실패 문구 찾기
            fail_text = self.text_finder(self.fail_login_path)
            if (fail_text == "잘못된 비밀번호입니다. 다시 확인하세요.") or (fail_text =="입력한 사용자 이름을 사용하는 계정을 찾을 수 없습니다. 사용자 이름을 확인하고 다시 시도하세요."):
                # self.mini_message = threading.Thread(self.showMessageBox("로그인 오류","잘못된 ID/PW 입니다."))
                # self.mini_message.start()
                self.showMessageBox("로그인 오류","잘못된 ID/PW 입니다.")



    # def Warning_event(self,case, text) :
    #     QMessageBox.about(self,case,text)
    def showMessageBox(self,case,text):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setText(case)
        msg.setInformativeText(text)
        msg.setWindowTitle("오류")
        msg.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
        retval = msg.exec_()
        # if self.mini_message.is_alive():
        #     self.mini_message.join()



        # 로그인 신호 로그인에서 받고 크롬 실행 + 아이디, 비밀번호 입력
    def selenium_test(self):
           # 기본 크롤링은 인스타. 이외의 링크는 취급 x
        # url ="https://httpbin.org/headers"
        # 여기서 로그인 하고 아래 본격적인 크롤링 시작하기
        pass

