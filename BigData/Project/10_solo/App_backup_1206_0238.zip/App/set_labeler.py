from PyQt5.QtCore import pyqtSignal,QThread
from PyQt5.QtWidgets import *


class labeler(QThread):
    def __init__(self, signal, form_class):
        super().__init__()
        self.ui = form_class
        self.signal = signal

    def run(self):
        self.signal.system_message_signal.connect(self.set_text)
        pass

    def set_text(self,text):
        self.ui.system_message.setText(text)


