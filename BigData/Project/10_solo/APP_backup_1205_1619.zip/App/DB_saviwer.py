import sqlite3

from PyQt5 import uic
from PyQt5.QtCore import (QThread, pyqtSignal)
from PyQt5.QtWidgets import *
from collections import deque

class DB_Saviwer(QThread):
    def __init__(self, signal, showtable):
        super().__init__()
        self.signal = signal
        self.showtable = showtable
        self.link_deque = deque()
        self.crawling_deque = deque()
        self.signal.closecon_signal.connect(self.close_con)
        
         # 링크 받아옴.


    # [LINK, ONER_ID, MAINTEXT, LOVER, HASHTAG]
    def run(self):
        self.con = sqlite3.connect("insta.db")
        self.Cur = self.con.cursor()
        self.create_table()
        # 이거는 처음에 다 보이는거잖아. 근데 내가 지금 크롤링된 부분만 볼거니까 나중에 조건값에 맞는 것만 띄우자고.
        # if self.showtable is not None:
        #     self.load_data()
        # 1차 링크 받을 시그널. str으로 링크만 받는다.
        self.signal.link_saver_signal.connect(self.data_receiver)
        # 데이터 저장 파트.
        while True: # 큐에 데이터추가 시 바로 반응할 수 있도록 항상 돌고 있음.
            if self.link_deque:
                save_link = self.link_deque.popleft()
                self.insert_linkdata(save_link)
                if self.showtable is not None:
                    self.load_data()
            # 최종 크롤링 데이터
            elif self.crawling_deque:
                self_data = self.crawling_deque.popleft()
                # 올 데이터 다 넣는걸로 하나씩 해드리고.
                if self.showtable is not None:
                    self.load_data()
            else:
                self.sleep(1)

            
    def close_con(self, check):
        if check:
            self.con.close()

    def load_data(self):
        self.showtable.clearContents()
        self.showtable.setRowCount(0)
        # self.Cur.execute("SELECT * FROM insta")
        self.Cur.execute("SELECT * FROM insta")
        data = self.Cur.fetchall()
        
        for row_index, row_data in enumerate(data):
            self.showtable.insertRow(row_index)
            for col_index, per_data in enumerate(row_data):
                item = QTableWidgetItem(str(per_data))
                self.showtable.setItem(row_index,col_index, item)

    def insert_linkdata(self, link):
        try:
            sql = "INSERT OR IGNORE INTO insta (LINK) VALUES (?)"
            data = (link,)
            self.Cur.execute(sql, data)
        except Exception as e:
            print("에러 발생", e)
        finally:
            self.con.commit()
            # "INSERT INTO example_table (column1, column2) VALUES (?, ?)", ('value1', 'value2')
            # "INSERT OR REPLACE INTO example_table (id, name) VALUES (?, ?)", (1, 'John')
            # cursor.execute("INSERT OR IGNORE INTO example_table (id, name) VALUES (?, ?)", (1, 'John'))

    def data_receiver(self, link):
        self.link_deque.append(link)

    # 테이블 생성 
    def create_table(self):
        sql = """CREATE TABLE IF NOT EXISTS insta(
            LINK TEXT,
            Oner_ID TEXT,
            MAINTEXT TEXT,
            LOVER TEXT
            HASHTAG TEXT
            );"""
        self.Cur.execute(sql)



    # def run(self):
    #     SQL = DB_Saver()
    #     SQL.create_table
    #     SQL.insert_data("계정주인", "본문내용", "해시태그")

