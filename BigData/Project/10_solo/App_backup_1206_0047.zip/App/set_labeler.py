from PyQt5.QtCore import pyqtSignal,QThread
from PyQt5.QtWidgets import *


class labeler(QThread):
    def __init__(self, signal, form_class):
        super().__init__()
        self.ui = form_class
        self.signal = signal

    def run(self):
        self.ui.system_message.setText("")
        pass

    

