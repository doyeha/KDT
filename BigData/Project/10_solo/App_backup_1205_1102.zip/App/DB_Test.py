import sqlite3

from PyQt5 import uic
from PyQt5.QtCore import (QThread, pyqtSignal)

class Test(QThread):
    con = sqlite3.connect("test.db")
    Cur = con.cursor()

    def create_table(self):
        sql = """CREATE TABLE IF NOT EXISTS test(
            Oner_ID TEXT,
            MAINTEXT TEXT,
            HASHTAG TEXT
            );"""
        self.Cur.execute(sql)

    def insert_data(self, data1, data2, data3):
        try:
            sql = "INSERT INTO test VALUES (?, ?, ?)"
            data = (data1, data2, data3)
            self.Cur.execute(sql, data)
        except Exception as e:
            print("에러 발생", e)
        finally:
            self.con.commit()

    def run(self):
        SQL = Test()
        SQL.create_table
        SQL.insert_data("계정주인", "본문내용", "해시태그")

