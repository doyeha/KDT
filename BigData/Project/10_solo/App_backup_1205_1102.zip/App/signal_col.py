from PyQt5.QtCore import pyqtSignal, QObject


class signal_collection(QObject):
    go_Mainview_signal = pyqtSignal(bool)
    idpw_signal = pyqtSignal(str, str, bool)    # ID, PW, login_try
    open_driver_Mainview_signal = pyqtSignal(bool)
    reset_idpw_signal = pyqtSignal(bool)
    login_success_signal = pyqtSignal(bool)
    start_crawling_signal = pyqtSignal(str, str, bool, bool, bool, bool, int)

    def __init__(self):
        super().__init__()

