
from PyQt5.QtCore import pyqtSignal,QThread

# 본인 모듈 import 
from signal_col import signal_collection

# 셀레니움 크롤링 모듈
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options

import time
import random as rd

class crawling_sele(QThread):
    def __init__(self, signal):
        super().__init__()
        self.ID = None
        self.PW = None
        self.signal = signal
        # self.signal.idpw_signal.connect(self.login_info_receiver)   # idpw 받아옴.
        self.open_check = True
        self.signal.open_driver_Mainview_signal.connect(self.open_driver)
        self.login_try = False
        print("쓰레드 시작")
        

    def open_driver(self, ch):
        if ch:
            print("셀레니움 실행")
            options = Options()
            user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
            options.add_argument(f"user-agent={user_agent}")
            chrome_driver_path = "chromedriver.exe"  # 크롬 드라이버 설치 경로 입력
            service = Service(chrome_driver_path)
            # 웹 드라이버 실행
            self.driver = webdriver.Chrome(options=options)
            self.url ="https://www.instagram.com"
            self.driver.get(self.url)
            # self.driver.set_window_position(100, 100)
            # self.driver.set_window_size(1024, 768)
            # self.open_check = False
            ch = False
            

    
    idinput_path = [ # 로그인 ID 입력 창 
        # (By.CLASS_NAME, '_aa4b _add6 _ac4d _ap35'),
        # (By.CLASS_NAME, '_aa4b._add6._ac4d._ap35'),
        (By.CSS_SELECTOR,'#loginForm > div > div:nth-child(1) > div > label > input'),
        (By.XPATH, '//*[@id="loginForm"]/div/div[1]/div/label/input'),
        (By.XPATH, "/html/body/div[2]/div/div/div[2]/div/div/div[1]/div[1]/div/section/main/div/div/div[1]/div[2]/div/form/div/div[1]/div/label/input")
        ]
    pwinput_path = [ # 로그인 PW 입력 창 
        # (By.CLASS_NAME, '_aa4b _add6 _ac4d _ap35'),
        # (By.CLASS_NAME, '_aa4b._add6._ac4d._ap35'),
        (By.CSS_SELECTOR, '#loginForm > div > div:nth-child(2) > div > label > input'),
        (By.XPATH, '//*[@id="loginForm"]/div/div[2]/div/label/input'),
        (By.XPATH, '/html/body/div[2]/div/div/div[2]/div/div/div[1]/div[1]/div/section/main/div/div/div[1]/div[2]/div/form/div/div[2]/div/label/input')
        ]
    log_submit_path = [ # 로그인 입력 버튼 클릭.
        # (By.CLASS_NAME, 'x9f619.xjbqb8w.x78zum5.x168nmei.x13lgxp2.x5pf9jr.xo71vjh.x1n2onr6.x1plvlek.xryxfnj.x1c4vz4f.x2lah0s.xdt5ytf.xqjyukv.x1qjc9v5.x1oa3qoh.x1nhvcw1'),
        # (By.CLASS_NAME, 'x9f619 xjbqb8w x78zum5 x168nmei x13lgxp2 x5pf9jr xo71vjh x1n2onr6 x1plvlek xryxfnj x1c4vz4f x2lah0s xdt5ytf xqjyukv x1qjc9v5 x1oa3qoh x1nhvcw1'),
        (By.CSS_SELECTOR, '#loginForm > div > div:nth-child(3) > button > div'),
        (By.XPATH, '//*[@id="loginForm"]/div/div[3]/button/div'),
        (By.XPATH, '/html/body/div[2]/div/div/div[2]/div/div/div[1]/div[1]/div/section/main/article/div[2]/div[1]/div[2]/div/form/div/div[3]/button/div')
        ]
    fail_login_path = [ # 로그인 실패 문구 찾는 path
        (By.CLASS_NAME, 'x1lliihq x1plvlek xryxfnj x1n2onr6 x1ji0vk5 x18bv5gf x193iq5w xeuugli x1fj9vlw x13faqbe x1vvkbs x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x x1i0vuye xvs91rp xo1l8bm x5n08af x1tu3fi x3x7a5m x10wh9bi x1wdrske x8viiok x18hxmgj'),
        (By.CLASS_NAME, 'x1lliihq x1plvlek xryxfnj x1n2onr6 x1ji0vk5 x18bv5gf x193iq5w xeuugli x1fj9vlw x13faqbe x1vvkbs x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x x1i0vuye xvs91rp xo1l8bm x5n08af x1tu3fi x3x7a5m x10wh9bi x1wdrske x8viiok x18hxmgj'.replace(" ",".")),
        (By.CSS_SELECTOR, '#loginForm > span'),
        (By.XPATH, '//*[@id="loginForm"]/span'),
        (By.XPATH, '/html/body/div[2]/div/div/div[2]/div/div/div[1]/div[1]/div/section/main/div/div/div[1]/div[2]/div/form/span')
        ]

    # path 리스트 입력 시 크롤링 되는 text 리턴
    def text_finder(self, path_list):
        # 조건 충족하는 버튼 클릭시키는 함수.
        for by, path in path_list:
            try:
                target_text = self.driver.find_element(by, path)
                self.timesleep_under_1s()
                break # 되면 더 찾지마
            except:           
                continue
        return target_text
        # 이걸 해서 찾는 결과물.
        # 1. 조건에 맞는 버튼 클릭
        # 2. 조건 충족 시 text 출력
        # 3. 조건 미충족 시 다음 이벤트로 안넘어가게 하기.

    # 찾는 리스트로 해서 텍스트 입력하는 함수
    # 아이디, 비밀번호 
    def text_sendkey(self, path_list, input_text):
        for by, path in path_list:  # 아이디 입력
                try:
                    self.driver.find_element(by, path).send_keys(input_text)
                    self.timesleep_under_1s()
                    break # 되면 더 찾지마
                except:           
                    continue





    def run(self):
        # 만약 로그인창이라면?
        self.signal.idpw_signal.connect(self.login_info_receiver)     # ID/PW 비밀번호 받아오는 시그널.
        

    def timesleep_under_1s(self):
        time.sleep(rd.choice(0.1,0.2,0.4,0.5,0.7,0.8,1.0))

    def login_info_receiver(self, id, pw, login_try):
        self.ID = id
        self.PW = pw
        self.login_try = login_try
        # print("self.login_try : ", self.login_try)
        self.Try_login()  
        
    def Try_login(self):
        if self.login_try:
            for by, path in self.idinput_path:  # 아이디 입력
                try:
                    self.driver.find_element(by, path).send_keys(self.ID)
                    self.timesleep_under_1s()
                    break # 되면 더 찾지마
                except:           
                    continue
            for by, path in self.pwinput_path:  # 비밀번호 입력
                try:
                    self.driver.find_element(by, path).send_keys(self.PW) 
                    self.timesleep_under_1s()
                    break # 되면 더 찾지마
                except:             
                    continue

            for by, path in self.log_submit_path:
                try:
                    self.login_btn = self.driver.find_element(by, path)
                    if self.login_btn.text == "로그인":
                        self.driver.find_element(by, path).click()
                        self.timesleep_under_1s()
                    # break # 되면 더 찾지마
                except:           
                    continue
            # 일단 여기서 로그인이 되면 문제가 없는데, 만약 문제가 생기면 ?

            
            self.login_try = False
      
    





    
        # 로그인 신호 로그인에서 받고 크롬 실행 + 아이디, 비밀번호 입력
    def selenium_test(self):
           # 기본 크롤링은 인스타. 이외의 링크는 취급 x
        # url ="https://httpbin.org/headers"
        # 여기서 로그인 하고 아래 본격적인 크롤링 시작하기
        
        pass

