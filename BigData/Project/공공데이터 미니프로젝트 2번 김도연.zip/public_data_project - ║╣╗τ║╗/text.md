태풍 - 김도연
홍수 - 김현주
지진 - 전민규
산불 - 박형준


- 태풍 
 : 고기압 - 저기압의 차이로 인해 태풍이 생성.
 
1. 기온변화 
-> GlobalLandTemperatures_GlobalLandTemperaturesByCountry.csv 사용.
    Climate로 DF생성.
    index dt / 평균 기온 / 평균 기온 불확실성 / 나라(영어 - 한글 깨짐 문제)

2. 태풍 발생 시기 및 빈도 
3. 
재산피해
인재피해 규모

